(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_245674ff._.js",
  "static/chunks/src_registry_1b13ee99._.js"
],
    source: "dynamic"
});
