(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f2cc2318._.js",
  "static/chunks/node_modules_next_5bed2878._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_abff55b9._.js"
],
    source: "dynamic"
});
