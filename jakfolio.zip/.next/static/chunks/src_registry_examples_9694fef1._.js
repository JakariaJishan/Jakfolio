(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_registry_4a3eb5a7._.js",
  "static/chunks/src_registry_examples_apple-hello-effect-vi-demo_tsx_d92b7af0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_registry_b1f8ad70._.js",
  "static/chunks/src_registry_examples_apple-hello-effect-en-demo_tsx_d92b7af0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/theme-switcher-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_registry_d8794f4d._.js",
  "static/chunks/src_registry_examples_theme-switcher-demo_tsx_d92b7af0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/theme-switcher-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/src_registry_examples_wheel-picker-demo_tsx_2750f8ab._.js",
  "static/chunks/src_registry_examples_wheel-picker-demo_tsx_d92b7af0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/work-experience-demo.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_245674ff._.js",
  "static/chunks/src_registry_1b13ee99._.js",
  "static/chunks/src_registry_examples_work-experience-demo_tsx_d92b7af0._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/work-experience-demo.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-client] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-client] (ecmascript)");
    });
});
}),
]);