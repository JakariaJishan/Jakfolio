(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/components/ui/sonner.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_2e30456c._.js",
  "static/chunks/src_7596b4ad._.js",
  "static/chunks/src_components_ui_sonner_tsx_7348d713._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/ui/sonner.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);