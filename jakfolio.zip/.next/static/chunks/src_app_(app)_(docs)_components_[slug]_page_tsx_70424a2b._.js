(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_registry_examples_9694fef1._.js",
  "static/chunks/src_7caaf1db._.js",
  "static/chunks/node_modules_motion-dom_dist_es_b963a962._.js",
  "static/chunks/node_modules_framer-motion_dist_es_fea08069._.js",
  "static/chunks/node_modules_zod_v3_511383c7._.js",
  "static/chunks/node_modules_1c37f0e3._.js",
  "static/chunks/node_modules_@ncdai_react-wheel-picker_dist_index_c2f8c891.css"
],
    source: "dynamic"
});
