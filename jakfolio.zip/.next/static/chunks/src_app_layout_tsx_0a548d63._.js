(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__5aa30003._.css",
  "static/chunks/src_components_ui_sonner_tsx_7e7d5627._.js",
  "static/chunks/node_modules_dad0aa59._.js",
  "static/chunks/src_components_providers_tsx_a5078426._.js"
],
    source: "dynamic"
});
