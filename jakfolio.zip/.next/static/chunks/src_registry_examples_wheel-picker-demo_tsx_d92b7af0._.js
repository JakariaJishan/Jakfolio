(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_registry_examples_wheel-picker-demo_tsx_2750f8ab._.js"
],
    source: "dynamic"
});
