module.exports = [
"[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_0acc372f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_2e59855f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/theme-switcher-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_1a7856dc._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/theme-switcher-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_examples_wheel-picker-demo_tsx_e2266149._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/work-experience-demo.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_6c6f1eb0._.js",
  "server/chunks/ssr/[root-of-the-server]__8b81358a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/work-experience-demo.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-ssr] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-ssr] (ecmascript)");
    });
});
}),
];