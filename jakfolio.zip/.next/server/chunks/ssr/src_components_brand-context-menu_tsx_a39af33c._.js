module.exports = [
"[project]/src/components/brand-context-menu.tsx [app-rsc] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/components/brand-context-menu.tsx [app-rsc] (ecmascript)"));
}),
];