module.exports = [
"[project]/src/registry/apple-hello-effect/index.ts [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$registry$2f$apple$2d$hello$2d$effect$2f$apple$2d$hello$2d$effect$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/registry/apple-hello-effect/apple-hello-effect.tsx [app-ssr] (ecmascript)");
;
}),
"[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>VietnameseDemo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$registry$2f$apple$2d$hello$2d$effect$2f$index$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/registry/apple-hello-effect/index.ts [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$registry$2f$apple$2d$hello$2d$effect$2f$apple$2d$hello$2d$effect$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/registry/apple-hello-effect/apple-hello-effect.tsx [app-ssr] (ecmascript)");
;
;
function VietnameseDemo() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$registry$2f$apple$2d$hello$2d$effect$2f$apple$2d$hello$2d$effect$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AppleHelloVietnameseEffect"], {}, void 0, false, {
        fileName: "[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx",
        lineNumber: 4,
        columnNumber: 10
    }, this);
}
}),
];

//# sourceMappingURL=src_registry_0acc372f._.js.map