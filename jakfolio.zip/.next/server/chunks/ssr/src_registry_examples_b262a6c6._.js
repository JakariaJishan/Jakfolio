module.exports = [
"[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_0c805ad5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-vi-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_8967a608._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/apple-hello-effect-en-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/theme-switcher-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_01b9274a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/theme-switcher-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/_34103981._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_examples_wheel-picker-form-demo_tsx_7853612a._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/wheel-picker-form-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/work-experience-demo.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_c13dde9a._.js",
  "server/chunks/ssr/src_registry_4e76c15e._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/work-experience-demo.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_examples_slide-to-unlock-demo-1_tsx_096330c6._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-1.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_examples_slide-to-unlock-demo-2_tsx_fca6555d._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-2.tsx [app-rsc] (ecmascript)");
    });
});
}),
"[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_registry_examples_slide-to-unlock-demo-3_tsx_32d3627f._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/registry/examples/slide-to-unlock-demo-3.tsx [app-rsc] (ecmascript)");
    });
});
}),
];