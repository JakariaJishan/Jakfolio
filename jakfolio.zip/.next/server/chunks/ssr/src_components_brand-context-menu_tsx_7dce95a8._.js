module.exports = [
"[project]/src/components/brand-context-menu.tsx [app-rsc] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/src_components_brand-context-menu_tsx_a39af33c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/components/brand-context-menu.tsx [app-rsc] (ecmascript, next/dynamic entry)");
    });
});
}),
];