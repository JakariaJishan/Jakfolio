module.exports = [
"[project]/.next-internal/server/app/manifest.webmanifest/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/features/profile/data/user.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "USER",
    ()=>USER
]);
const USER = {
    firstName: "Jakaria",
    lastName: "Jishan",
    displayName: "Jakaria Jishan",
    username: "jakariajishan",
    gender: "male",
    pronouns: "he/him",
    bio: "Building thoughtful web experiences.",
    flipSentences: [
        "Building thoughtful web experiences.",
        "Software Developer",
        "Crafting clean and scalable backend systems"
    ],
    address: "ECB Chattar, Dhaka Cantonment, Dhaka - 1206",
    phoneNumber: "Kzg4MDE4MjMyNTYwNTM=",
    email: "amFrYXJpYWppc2hhbjAwNkBnbWFpbC5jb20=",
    website: "#",
    jobTitle: "Software Engineer",
    jobs: [
        {
            title: "Laravel Developer",
            company: "WemaxDevs",
            website: "https://wemaxdevs.com/"
        },
        {
            title: "Jr. Software Engineer",
            company: "DevSpace",
            website: "https://www.linkedin.com/company/devspacebd"
        },
        {
            title: "CTO & Co-Founder",
            company: "Infivro",
            website: "https://infivro.com"
        }
    ],
    about: `
Hello, World! I am Md. Golam Jakaria — a Software Engineer passionate about creating robust, user-centric web and mobile solutions with seamless functionality and modern designs.

With 3+ years of experience, I specialize in building high-quality full-stack applications using Next.js, React, Laravel, Ruby on Rails, and modern front-end and back-end technologies. Beyond work, I love exploring new tools and turning ideas into reality through personal projects and mentoring junior developers.

One of my key projects, [KokoLive](https://github.com/kh-abir/koko-live-admin), developed in 2024, is an engaging mobile application similar to TikTok, where users can create, share, and interact with live streaming and short videos. It includes a robust admin panel for content moderation and user management, built with Flutter for the mobile app, React.js for the admin panel, and Ruby on Rails for the backend.

I'm also the creator of an [E-commerce Admin Panel](https://github.com/JakariaJishan/next-ecommerce-api) — a Laravel & Next.js-based application built for dynamic routing, server-side rendering, and responsive styling with Tailwind CSS. It features clean code through custom ESLint configurations, shared components, data validation schemas, and flexible deployment options.

Let's connect and collaborate!
  `,
    avatar: "/images/brand-ghibli1.png",
    ogImage: "https://assets.chanhdai.com/images/screenshot-og-image-light.png?t=1759581475",
    namePronunciationUrl: "/audio/chanhdai.mp3",
    keywords: [
        "jakariajishan",
        "kokolive",
        "infivro"
    ],
    dateCreated: "2025-10-11"
};
}),
"[project]/src/config/site.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GITHUB_USERNAME",
    ()=>GITHUB_USERNAME,
    "MAIN_NAV",
    ()=>MAIN_NAV,
    "META_THEME_COLORS",
    ()=>META_THEME_COLORS,
    "SITE_INFO",
    ()=>SITE_INFO,
    "SOURCE_CODE_GITHUB_REPO",
    ()=>SOURCE_CODE_GITHUB_REPO,
    "SOURCE_CODE_GITHUB_URL",
    ()=>SOURCE_CODE_GITHUB_URL,
    "UTM_PARAMS",
    ()=>UTM_PARAMS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$profile$2f$data$2f$user$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/features/profile/data/user.ts [app-route] (ecmascript)");
;
const SITE_INFO = {
    name: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$profile$2f$data$2f$user$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["USER"].displayName,
    url: process.env.APP_URL || "https://chanhdai.com",
    ogImage: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$profile$2f$data$2f$user$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["USER"].ogImage,
    description: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$profile$2f$data$2f$user$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["USER"].bio,
    keywords: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$features$2f$profile$2f$data$2f$user$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["USER"].keywords
};
const META_THEME_COLORS = {
    light: "#ffffff",
    dark: "#09090b"
};
const MAIN_NAV = [
    {
        title: "Jakfolio",
        href: "/"
    }
];
const GITHUB_USERNAME = "jakariajishan";
const SOURCE_CODE_GITHUB_REPO = "https://github.com/JakariaJishan";
const SOURCE_CODE_GITHUB_URL = "https://github.com/JakariaJishan";
const UTM_PARAMS = {
};
}),
"[project]/src/app/manifest.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>manifest
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$site$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/site.ts [app-route] (ecmascript)");
;
function manifest() {
    return {
        short_name: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$site$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SITE_INFO"].name,
        name: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$site$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SITE_INFO"].name,
        description: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$site$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SITE_INFO"].description,
        icons: [
            {
                src: "https://assets.chanhdai.com/images/icon-vector.svg",
                type: "image/svg+xml",
                sizes: "any",
                purpose: "any"
            },
            {
                src: "https://assets.chanhdai.com/images/icon-192x192.png",
                type: "image/png",
                sizes: "192x192",
                purpose: "any"
            },
            {
                src: "https://assets.chanhdai.com/images/icon-512x512.png",
                type: "image/png",
                sizes: "512x512",
                purpose: "any"
            },
            {
                src: "https://assets.chanhdai.com/images/maskable-icon.png",
                type: "image/png",
                sizes: "512x512",
                purpose: "maskable"
            }
        ],
        id: "/?utm_source=pwa",
        start_url: "/?utm_source=pwa",
        display: "standalone",
        scope: "/",
        screenshots: [
            {
                src: "https://assets.chanhdai.com/images/screenshot-mobile-dark.webp",
                type: "image/webp",
                sizes: "440x956",
                form_factor: "narrow"
            },
            {
                src: "https://assets.chanhdai.com/images/screenshot-mobile-light.webp",
                type: "image/webp",
                sizes: "440x956",
                form_factor: "narrow"
            },
            {
                src: "https://assets.chanhdai.com/images/screenshot-desktop-dark.webp",
                type: "image/webp",
                sizes: "1920x1080",
                form_factor: "wide"
            },
            {
                src: "https://assets.chanhdai.com/images/screenshot-desktop-light.webp",
                type: "image/webp",
                sizes: "1920x1080",
                form_factor: "wide"
            }
        ]
    };
}
}),
"[project]/src/app/manifest--route-entry.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/manifest.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$metadata$2f$resolve$2d$route$2d$data$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/metadata/resolve-route-data.js [app-route] (ecmascript)");
;
;
;
const contentType = "application/manifest+json";
const cacheControl = "public, max-age=0, must-revalidate";
const fileType = "manifest";
if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"] !== 'function') {
    throw new Error('Default export is missing in "./manifest.ts"');
}
async function GET() {
    const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
    const content = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$metadata$2f$resolve$2d$route$2d$data$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resolveRouteData"])(data, fileType);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](content, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
;
}),
"[project]/src/app/manifest--route-entry.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2d2d$route$2d$entry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["GET"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2d2d$route$2d$entry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/src/app/manifest--route-entry.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$manifest$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/manifest.ts [app-route] (ecmascript)");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__100e50f6._.js.map