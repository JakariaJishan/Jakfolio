var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/node_modules_next_033db752._.js")
R.c("server/chunks/[root-of-the-server]__100e50f6._.js")
R.m("[project]/.next-internal/server/app/manifest.webmanifest/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/manifest--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/manifest--route-entry.js [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
