import { AppleHelloEnglishEffect } from "@/registry/apple-hello-effect";

export default function EnglishDemo() {
  return <AppleHelloEnglishEffect />;
}
