import { AppleHelloVietnameseEffect } from "@/registry/apple-hello-effect";

export default function VietnameseDemo() {
  return <AppleHelloVietnameseEffect />;
}
