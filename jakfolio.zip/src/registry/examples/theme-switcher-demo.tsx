import { ThemeSwitcher } from "@/registry/theme-switcher";

export default function ThemeSwitcherDemo() {
  return <ThemeSwitcher />;
}
