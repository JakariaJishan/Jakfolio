export type NavItem = {
  title: string;
  href: string;
};
