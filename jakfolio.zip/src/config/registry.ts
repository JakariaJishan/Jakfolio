export const registryConfig = {
  /** Used to replace the <registryBaseUrl> placeholder in dependency paths */
  baseUrl: process.env.REGISTRY_URL || "https://chanhdai.com/r",
};
